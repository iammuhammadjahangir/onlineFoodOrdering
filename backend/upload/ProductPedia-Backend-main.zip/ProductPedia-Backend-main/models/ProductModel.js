const mongoose = require("mongoose");
const productSchema = new mongoose.Schema(
  {
    barcode: [
      {
        type: String,
      },
    ],
    name: {
      type: String,
      require: true,
    },
    discription: {
      type: String,
    },
    category: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "category",
      },
    ],
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "company",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);
const product = mongoose.model("product", productSchema);
module.exports = product;
