const mongoose = require("mongoose");
const tempProductSchema = new mongoose.Schema({
  barcode: {
    type: String,
    unique: true,
  },
  productName: {
    type: String,
    required: true,
  },
  company: {
    type:String
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});
const product = mongoose.model("tempProduct", tempProductSchema);
module.exports = product;
