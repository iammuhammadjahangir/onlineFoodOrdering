const productModel = require("../models/ProductModel");
const TempProduct = require("../models/tempProductModal");
const mongoose = require("mongoose");

module.exports = {
  getAllProducts: async (req, res) => {
    try {
      let data = await productModel
        .find()
        .populate({
          path: "company",
          populate: {
            path: "country",
            model: "country",
          },
        })
        .sort({ name: 1 });
      res.send(data);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).send("Internal Server Error");
    }
  },
  postProduct: async (req, res) => {
    try {
      console.log(req.body);
      // // Check if product already exists with the given barcode
      // const existingProduct = await productModel.findOne({
      //   barcode: req.body.barcode,
      // });
      // if (existingProduct) {
      //   return res
      //     .status(400)
      //     .json({ error: "Product with this barcode already exists" });
      // }

      // Create a new product instance
      let data = new productModel(req.body);

      // Save the new product
      let result = await data.save();
      console.log(result);

      // // If product saved successfully, delete temporary product with the same barcode
      // if (result) {
      //   await TempProduct.deleteOne({ barcode: req.body.barcode });
      // }

      // Send response
      res.status(200).json({ msg: "Product saved successfully", data: result });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },

  updateProduct: async (req, res) => {
    try {
      console.log(req.body);
      const productId = req.body.id;
      const updatedProductData = req.body.product;

      const result = await productModel.updateOne(
        { _id: new mongoose.Types.ObjectId(productId) },
        { $set: updatedProductData }
      );

      console.log(result);
      if (result.nModified === 0) {
        return res
          .status(200)
          .send({ msg: "No changes applied to the product." });
      }
      res.send({ msg: "Product updated successfully" });
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).send({ msg: "Internal Server Error" });
    }
  },
  deleteProduct: async (req, res) => {
    try {
      const productId = new mongoose.Types.ObjectId(req.params.productId);

      // Check if the product exists before attempting to delete
      const existingProduct = await productModel.findById(productId);

      if (!existingProduct) {
        return res.status(200).send({ msg: "Product not found" });
      }

      // If the product exists, proceed with deletion
      const result = await productModel.deleteOne({ _id: productId });

      if (result.deletedCount > 0) {
        res.status(200).send({ msg: "Product deleted successfully" });
      } else {
        res.status(500).send({ msg: "Error deleting product" });
      }
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).send({ msg: "Internal Server Error" });
    }
  },
  addTempProduct: async (req, res) => {
    try {
      const { barcode, productName, company } = req.body;
      console.log(req.body);

      const tempProduct = await TempProduct.create({
        barcode,
        productName,
        company,
      });

      if (tempProduct) {
        res.json({
          message: "Product Add Successfully",
        });
      }
    } catch (error) {
      if (error.code === 11000) {
        res.status(409).json({
          message: "This Bar Code is already registered",
        });
      } else {
        // Handle other errors
        console.error(error);
        res.status(500).json({
          message: "Internal server error.",
        });
      }
    }
  },
  getTempProduct: async (req, res) => {
    try {
      let data = await TempProduct.find();
      res.send(data);
    } catch (error) {
      console.log(console.error());
    }
  },
  delTempProduct: async (req, res) => {
    try {
      console.log(req.params.productId);
      const productId = req.params.productId;

      // Check if the product exists before attempting to delete
      const existingProduct = await TempProduct.findById(productId);

      if (!existingProduct) {
        return res.status(200).send({ msg: "Product not found" });
      }

      // If the product exists, proceed with deletion
      const result = await TempProduct.deleteOne({ _id: productId });

      if (result.deletedCount > 0) {
        res.status(200).send({ msg: "Product deleted successfully" });
      } else {
        res.status(500).send({ msg: "Error deleting product" });
      }
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).send({ msg: "Internal Server Error" });
    }
  },
  getBarcodeProduct: async (req, res) => {
    try {
      console.log(req.params.barcode);
      let product = await productModel
        .find({ barcode: { $elemMatch: { $eq: req.params.barcode } } })
        .populate({
          path: "company",
          populate: {
            path: "country",
            model: "country",
          },
        })
        .populate("category");
      console.log(product);
      if (product) {
        res.json({
          success: true,
          product,
        });
      } else {
        res.json({
          success: false,
        });
      }
    } catch (error) {
      res.json({
        message: "Internal Server Error",
      });
    }
  },
  getProducts: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;

      let query = {}; // Initialize an empty query object

      // Fetch the total count of documents based on the constructed query
      const totalCount = await productModel.countDocuments(query);
      const totalPages = Math.ceil(totalCount / perPage);

      let products = await productModel
        .find(query)
        .populate({
          path: "company",
          populate: {
            path: "country",
            model: "country",
          },
        })
        .sort({ name: 1 })
        .skip((page - 1) * perPage)
        .limit(perPage);

      let totalDataCount = await productModel.countDocuments();
      console.log(totalDataCount);
      res.json({
        products,
        page,
        totalPages,
        totalCount,
        totalDataCount,
      });
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  },

  getFilteredProducts: async (req, res) => {
    try {
      let products;
      let totalDataCount;
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;
      const filterOption = req.query.filterOption.toString(); // Get the filter option from the query
      console.log(req.query);
      const totalCount = await productModel.countDocuments();
      const totalPages = Math.ceil(totalCount / perPage);

      if (filterOption === "company") {
        products = await productModel
          .find({ company: req.query.company })
          .populate({
            path: "company",
            populate: {
              path: "country",
              model: "country",
            },
          })
          .sort({ name: 1 });

        totalDataCount = products.length;
        console.log(totalDataCount);

        products = products.slice((page - 1) * perPage, page * perPage);
      } else if (filterOption === "country") {
        products = await productModel
          .find()
          .populate({
            path: "company",
            populate: {
              path: "country",
              model: "country",
            },
          })
          .sort({ name: 1 })
          .then((products) => {
            return products.filter((product) => {
              return (
                product.company &&
                product.company.country &&
                product.company.country._id.equals(req.query.country)
              );
            });
          });
        // const allProducts = await productModel
        //   .find()
        //   .populate({
        //     path: "company",
        //     populate: {
        //       path: "country",
        //       model: "country",
        //     },
        //   })
        //   .sort({ name: 1 });

        // const filteredProducts = allProducts.filter((product) => {
        //   return (
        //     product.company &&
        //     product.company.country &&
        //     product.company.country._id == req.query.country
        //   );
        // });
        totalDataCount = products.length;
        products = products.slice((page - 1) * perPage, page * perPage);
        console.log(products);
        // Paginate the filtered produ
      } else {
        products = await productModel
          .find({
            category: { $elemMatch: { $eq: req.query.category } }, // Search for products with the specified category
          })
          .populate({
            path: "company",
            populate: {
              path: "country",
              model: "country",
            },
          })
          .sort({ name: 1 });

        totalDataCount = products.length;

        // Paginate the results
        products = products.slice((page - 1) * perPage, page * perPage);
      }
      res.json({
        products,
        page,
        totalPages,
        totalCount,
        totalDataCount,
      });
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  },
};
