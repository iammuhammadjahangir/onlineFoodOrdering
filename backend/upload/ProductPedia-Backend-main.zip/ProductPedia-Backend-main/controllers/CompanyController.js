const mongoose = require("mongoose");
const companyModel = require("../models/CompanyModel");

module.exports = {
  getAllCompanies: async (req, res) => {
    let data = await companyModel.find().populate("country").sort({ name: 1 });
    res.send(data);
  },
  postCompany: async (req, res) => {
    try {
      console.log(req.body)
      let data = companyModel(req.body);
      let result = await data.save();
      res.send({ msg: "hello", data: result });
    } catch (error) {
      console.log(error)
      res.status(500).send("Internal server error");
    }
  },
  updateImage: async (req, res) => {
    console.log(req.body);
    console.log(req.file.path);
    try {
      const result = await companyModel.updateOne(
        { _id: req.body.companyId }, // Match the company by ID
        { $set: { companyLogo: req.file.path } } // Set the companyLogo field
      );
      console.log(result);
      if ((result.modifiedCount = 1)) {
        res.send("File uploaded successfully");
      } else {
        res.status(500).send("Failed to upload file");
      }
    } catch (error) {
      console.error(error);
      res.status(500).send("Internal server error");
    }
  },
  updateCompanyRecord: async (req, res) => {
    console.log(req.body);
    const Id = req.body.id;
    const updateRecord = req.body.Company;
    try {
      const result = await companyModel.updateOne(
        { _id: new mongoose.Types.ObjectId(Id) },
        { $set: updateRecord }
      );

      if (result.nModified === 0) {
        return res
          .status(200)
          .send({ msg: "No changes applied to the Company." });
      }
      res.send({ msg: "Company updated successfully" });
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).send({ msg: "Internal Server Error" });
    }
  },
};
