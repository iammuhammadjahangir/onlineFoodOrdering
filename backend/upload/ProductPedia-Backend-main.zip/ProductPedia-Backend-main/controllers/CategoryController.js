const categoryModel = require("../models/CategoryModel");
module.exports = {
  getAllCategories: async (req, res) => {
    let data = await categoryModel.find().sort({ name: 1 });
    res.send(data);
  },
  postCategory: async (req, res) => {
    let data = categoryModel(req.body);
    let result = await data.save();
    res.send({ msg: "hello", data: result });
  },
  deleteCategory: async (req, res) => {
    try {
      await categoryModel.deleteMany({
        name: { $nin: ["Baby Care", "Others"] },
      });
      res
        .status(200)
        .send(
          "Categories deleted successfully except 'baby care' and 'shampoo'."
        );
    } catch (err) {
      res.status(500).send("Error deleting categories: " + err.message);
    }
  },
};
