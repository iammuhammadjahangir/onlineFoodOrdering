const express = require('express')


const router = express.Router()

const companyController = require("../controllers/CompanyController")
const upload = require('../middleware/ImageUploader')
router.get('/getallcompanies', companyController.getAllCompanies)
router.post('/postcompany', companyController.postCompany)
router.post('/updateImage',upload.single('image'),companyController.updateImage)
router.put('/updateCompanyRecord',companyController.updateCompanyRecord)

module.exports = router;