const express = require('express')
const imageMiddleware = require('../middleware/ImageUploader')
const router = express.Router()

const productController = require("../controllers/ProductController")

router.get('/getallproducts', productController.getAllProducts)
router.post('/postproduct', productController.postProduct)
router.post('/addTempProduct',productController.addTempProduct)
router.get('/getTempProduct',productController.getTempProduct)
router.get('/getBarcodeProduct/:barcode',productController.getBarcodeProduct)
router.get('/getfilteredproducts', productController.getFilteredProducts)
router.put('/updateproduct', productController.updateProduct)
router.delete('/deleteproduct/:productId', productController.deleteProduct)
router.delete('/delTempProduct/:productId',productController.delTempProduct)
router.get('/getProduct',productController.getProducts)
module.exports = router;